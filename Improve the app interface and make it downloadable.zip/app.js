const D=864e5,KEY='homebase-v1',now=()=>Date.now();
let S;
let deferredInstall;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;render()});
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>Math.random().toString(36).slice(2,9);
function seed(){const t=now();return{tab:'today',
members:[{id:'m1',name:'Amma'},{id:'m2',name:'Appa'},{id:'m3',name:'Me'}],done:{m1:3,m2:1,m3:5},
items:[
{id:'i1',name:'LPG cylinder',e:'🔥',days:45,price:900,h:[t-82*D,t-40*D]},
{id:'i2',name:'Rice, 25 kg',e:'🍚',days:30,price:1400,h:[t-51*D,t-24*D]},
{id:'i3',name:'Cooking oil',e:'🫙',days:28,price:750,h:[t-45*D,t-18*D]},
{id:'i4',name:'RO filter',e:'💧',days:180,price:350,h:[t-300*D,t-120*D]}],
list:[],
tasks:[
{id:'t1',name:'Take out the trash',every:2,who:'m3',last:t-3*D},
{id:'t2',name:'Clean the water tank',every:14,who:'m2',last:t-10*D},
{id:'t3',name:'Pay the electricity bill',every:30,who:'m1',last:t-20*D},
{id:'t4',name:'Deep clean the kitchen',every:7,who:'m3',last:t-8*D}]}}
function load(){try{const r=localStorage.getItem(KEY);if(r)return JSON.parse(r)}catch(e){}return seed()}
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
S=load();

function predict(i){
  const h=i.h,iv=[];for(let k=1;k<h.length;k++)iv.push((h[k]-h[k-1])/D);
  const r=iv.slice(-4),avg=r.length?r.reduce((a,b)=>a+b,0)/r.length:i.days;
  const last=h.length?h[h.length-1]:now();
  const left=Math.ceil((last+avg*D-now())/D);
  return{left,avg:Math.max(avg,1)};
}
const cls=l=>l<=3?'bad':l<=7?'warn':'ok';
const mname=id=>(S.members.find(m=>m.id===id)||{name:'Unassigned'}).name;
const onList=i=>S.list.some(l=>l.itemId===i.id&&!l.done);
function addToList(i){if(!onList(i))S.list.push({id:uid(),name:i.name,itemId:i.id,done:false})}
const val=id=>{const e=document.getElementById(id);const v=e.value.trim();return v};

let sampleP;
async function ask(){
  const q=val('in-ask'),box=document.getElementById('ans');if(!q)return;
  box.textContent='Thinking...';
  try{
    sampleP=sampleP||(window.claude&&claude.use?claude.use('sample'):Promise.resolve(null));
    const sm=await sampleP;if(!sm){box.textContent='The assistant is not available here.';return}
    const ctx=JSON.stringify({today:new Date().toDateString(),stock:S.items.map(i=>({name:i.name,daysLeft:predict(i).left,priceInr:i.price||null})),shoppingList:S.list.filter(l=>!l.done).map(l=>l.name),chores:S.tasks.map(t=>({name:t.name,who:mname(t.who),dueInDays:Math.ceil((t.last+t.every*D-now())/D)}))});
    const r=await sm('You are Homebase, a practical household assistant for an Indian family. Answer in under 90 words using only this household data. Prices are in rupees. Be concrete.\nData: '+ctx+'\nQuestion: '+q,{onText:({text})=>{box.textContent=text},cache:false});
    box.textContent=r.text;
  }catch(e){box.textContent=e&&e.code==='not_granted'?'Allow the assistant to answer questions.':'Could not get an answer. Try again.'}
}
function todayView(){
  const it=S.items.map(i=>({i,p:predict(i)})),low=it.filter(x=>x.p.left<=3),soon=it.filter(x=>x.p.left>3&&x.p.left<=7);
  const due=S.tasks.filter(t=>Math.ceil((t.last+t.every*D-now())/D)<=0);
  const score=Math.max(0,Math.round(100-low.length*18-soon.length*6-due.length*10));
  const spend=Math.round(it.reduce((a,x)=>a+(x.i.price||0)/x.p.avg*30,0));
  const c=score>=80?'ok':score>=55?'warn':'bad',hr=new Date().getHours(),g=hr<12?'Good morning':hr<17?'Good afternoon':'Good evening',R=54,C=2*Math.PI*R;
  let h=`<h1>${g}</h1><p class="sub">Here is how your home is doing today.</p>
  <div class="card hero"><svg width="132" height="132" viewBox="0 0 132 132" role="img" aria-label="Home score ${score} out of 100"><circle cx="66" cy="66" r="${R}" fill="none" stroke="var(--bd)" stroke-width="12"/><circle cx="66" cy="66" r="${R}" fill="none" stroke="var(--${c})" stroke-width="12" stroke-linecap="round" stroke-dasharray="${C*score/100} ${C}" transform="rotate(-90 66 66)"/><text x="66" y="75" text-anchor="middle" font-size="34" font-weight="800" fill="var(--tx)">${score}</text></svg>
  <div class="grow"><div class="name">Home score</div><div class="mut">${low.length} running out, ${due.length} chore${due.length===1?'':'s'} due</div><div class="spend">₹${spend.toLocaleString('en-IN')}</div><div class="mut">estimated monthly spend on essentials</div></div></div><h2>Needs attention</h2>`;
  if(!low.length&&!soon.length&&!due.length)h+=`<div class="empty">All clear. Nothing needs you today.</div>`;
  low.concat(soon).forEach(({i,p})=>{h+=`<div class="card row"><div class="grow"><div class="name">${esc(i.name)}</div><div class="mut ${cls(p.left)}">${p.left<0?-p.left+' days overdue':p.left+' day'+(p.left===1?'':'s')+' left'}</div></div>${onList(i)?'<button disabled>On the list</button>':`<button class="p" data-a="tolist" data-id="${i.id}">Add to list</button>`}</div>`});
  due.forEach(t=>{h+=`<div class="card row"><div class="grow"><div class="name">${esc(t.name)}</div><div class="mut bad">${esc(mname(t.who))}’s chore is due</div></div><button class="p" data-a="taskdone" data-id="${t.id}">Mark done</button></div>`});
  h+=`<h2>Ask Homebase</h2><div class="card"><div class="form" style="margin:0"><input type="text" id="in-ask" placeholder="What do we need this week?" data-enter="ask"><button class="p" data-a="ask">Ask</button></div><div class="ans" id="ans"></div></div>`;
  return h;
}
function stockView(){
  const items=S.items.map(i=>({i,p:predict(i)})).sort((a,b)=>a.p.left-b.p.left);
  const low=items.filter(x=>x.p.left<=3).length;
  let h=`<h1>Stock</h1><p class="sub">${low?`${low} item${low>1?'s':''} will run out within 3 days.`:'Nothing is about to run out.'}</p>`;
  if(!items.length)h+=`<div class="empty">Add something your home uses up, like gas, rice or filters.</div>`;
  items.forEach(({i,p})=>{
    const c=cls(p.left),pct=Math.max(4,Math.min(100,p.left/p.avg*100));
    const txt=p.left<0?`${-p.left}`:p.left;
    const lab=p.left<0?'days overdue':p.left===1?'day left':'days left';
    h+=`<div class="card"><div class="row"><div style="font-size:26px">${esc(i.e||'📦')}</div>
    <div class="grow"><div class="name">${esc(i.name)}</div><div class="mut">Lasts about ${Math.round(p.avg)} days, restocked ${i.h.length} time${i.h.length===1?'':'s'}</div></div>
    <div class="days ${c}">${txt}<small>${lab}</small></div></div>
    <div class="bar ${c}"><i style="width:${pct}%"></i></div>
    <div class="acts"><button class="p" data-a="restock" data-id="${i.id}">Restocked today</button>
    ${onList(i)?'<button disabled>On the list</button>':`<button data-a="tolist" data-id="${i.id}">Add to list</button>`}
    <button class="x" data-a="delitem" data-id="${i.id}" aria-label="Remove ${esc(i.name)}">×</button></div></div>`;
  });
  h+=`<h2>Track something new</h2><div class="form"><input type="text" id="in-name" placeholder="Item name"><input type="number" id="in-days" min="1" placeholder="Lasts (days)"><input type="number" id="in-price" min="0" placeholder="Price (₹)"><button class="p" data-a="additem">Add item</button></div>`;
  return h;
}
function listView(){
  const sug=S.items.filter(i=>predict(i).left<=5&&!onList(i));
  let h=`<h1>Shopping list</h1><p class="sub">Shared by everyone in the household.</p>`;
  if(sug.length){h+=`<h2>Running low</h2><div>`;sug.forEach(i=>{h+=`<span class="chip">${esc(i.name)} <button data-a="tolist" data-id="${i.id}" aria-label="Add ${esc(i.name)}">Add</button></span>`});h+=`</div>`}
  h+=`<h2>To buy</h2>`;
  if(!S.list.length)h+=`<div class="empty">Your list is empty. Add an item below.</div>`;
  S.list.forEach(l=>{h+=`<div class="card li ${l.done?'d':''}"><input type="checkbox" data-a="tick" data-id="${l.id}" ${l.done?'checked':''} aria-label="Bought ${esc(l.name)}"><div class="grow name">${esc(l.name)}</div><button class="x" data-a="rmlist" data-id="${l.id}" aria-label="Remove ${esc(l.name)}">×</button></div>`});
  h+=`<div class="form"><input type="text" id="in-li" placeholder="Add an item" data-enter="addlist"><button class="p" data-a="addlist">Add</button><button data-a="share">Copy for WhatsApp</button>${S.list.some(l=>l.done)?'<button data-a="clearlist">Clear bought</button>':''}</div>`;
  return h;
}
function choresView(){
  const tasks=S.tasks.map(t=>({t,left:Math.ceil((t.last+t.every*D-now())/D)})).sort((a,b)=>a.left-b.left);
  const max=Math.max(1,...S.members.map(m=>S.done[m.id]||0));
  let h=`<h1>Chores</h1><p class="sub">Recurring tasks, split across the household.</p>`;
  h+=`<div class="card"><div class="name" style="margin-bottom:6px">Who has done what</div>`;
  S.members.forEach(m=>{const n=S.done[m.id]||0;h+=`<div class="fair"><b>${esc(m.name)}</b><div class="bar"><i style="width:${n/max*100}%"></i></div><span>${n}</span></div>`});
  h+=`</div>`;
  if(!tasks.length)h+=`<div class="empty">No chores yet. Add one below.</div>`;
  tasks.forEach(({t,left})=>{
    const c=left<0?'bad':left<=1?'warn':'ok';
    const when=left<0?`${-left} day${left===-1?'':'s'} overdue`:left===0?'Due today':`Due in ${left} day${left===1?'':'s'}`;
    h+=`<div class="card"><div class="row"><div class="grow"><div class="name">${esc(t.name)}</div><div class="mut">${esc(mname(t.who))}, every ${t.every} day${t.every===1?'':'s'}</div></div>
    <div class="${c}" style="font-weight:600;font-size:14px;text-align:right">${when}</div></div>
    <div class="acts" style="margin-top:10px"><button class="p" data-a="taskdone" data-id="${t.id}">Mark done</button><button class="x" data-a="deltask" data-id="${t.id}" aria-label="Remove ${esc(t.name)}">×</button></div></div>`;
  });
  const opts=S.members.map(m=>`<option value="${m.id}">${esc(m.name)}</option>`).join('');
  h+=`<h2>Add a chore</h2><div class="form"><input type="text" id="in-task" placeholder="Chore name"><input type="number" id="in-every" min="1" placeholder="Every (days)"><select id="in-who" aria-label="Assign to">${opts}</select><button class="p" data-a="addtask">Add chore</button></div>`;
  h+=`<h2>People</h2><div>`;
  S.members.forEach(m=>{h+=`<span class="chip">${esc(m.name)}</span>`});
  h+=`</div><div class="form"><input type="text" id="in-mem" placeholder="Add a person" data-enter="addmember"><button data-a="addmember">Add person</button></div>`;
  return h;
}
function render(){
  const t=S.tab;
  const body=t==='today'?todayView():t==='stock'?stockView():t==='list'?listView():choresView();
  const badge=S.list.filter(l=>!l.done).length;
  const nb=(k,e,l)=>`<button class="${t===k?'on':''}" data-a="tab" data-id="${k}"><span>${e}</span>${l}</button>`;
  const date=new Intl.DateTimeFormat('en-IN',{weekday:'short',day:'numeric',month:'short'}).format(new Date());
  document.getElementById('app').innerHTML=`<header class="topbar"><div class="brand"><div class="brandmark" aria-hidden="true">⌂</div><div><div class="eyebrow">HOUSEHOLD HQ</div><div class="brandname">homebase</div></div></div><div class="date-pill">${date}</div></header>${body}<nav><div>${nb('today','🏠','Today')}${nb('stock','📦','Stock')}${nb('list','🛒','List'+(badge?` (${badge})`:''))}${nb('chores','🧹','Chores')}</div></nav>`;
}
function act(a,id){
  if(a==='ask')return ask();
  if(a==='install'){if(deferredInstall){deferredInstall.prompt();deferredInstall=null}return}
  if(a==='share'){const t='Shopping list:\n'+S.list.filter(l=>!l.done).map(l=>'• '+l.name).join('\n');try{navigator.clipboard.writeText(t);alert('List copied. Paste it into WhatsApp.')}catch(e){alert(t)}return}
  if(a==='tab'){S.tab=id}
  else if(a==='restock'){const i=S.items.find(x=>x.id===id);i.h.push(now());S.list=S.list.filter(l=>l.itemId!==id)}
  else if(a==='tolist'){addToList(S.items.find(x=>x.id===id))}
  else if(a==='delitem'){S.items=S.items.filter(x=>x.id!==id);S.list=S.list.filter(l=>l.itemId!==id)}
  else if(a==='additem'){const n=val('in-name'),d=parseInt(val('in-days'),10);if(!n||!(d>0))return alert('Enter an item name and how many days it usually lasts.');S.items.push({id:uid(),name:n,e:'📦',days:d,price:parseInt(val('in-price'),10)||0,h:[now()]})}
  else if(a==='tick'){const l=S.list.find(x=>x.id===id);l.done=!l.done;if(l.done&&l.itemId){const i=S.items.find(x=>x.id===l.itemId);if(i)i.h.push(now())}}
  else if(a==='rmlist'){S.list=S.list.filter(l=>l.id!==id)}
  else if(a==='addlist'){const n=val('in-li');if(!n)return;S.list.push({id:uid(),name:n,done:false})}
  else if(a==='clearlist'){S.list=S.list.filter(l=>!l.done)}
  else if(a==='taskdone'){const t=S.tasks.find(x=>x.id===id);t.last=now();S.done[t.who]=(S.done[t.who]||0)+1}
  else if(a==='deltask'){S.tasks=S.tasks.filter(x=>x.id!==id)}
  else if(a==='addtask'){const n=val('in-task'),e=parseInt(val('in-every'),10);if(!n||!(e>0))return alert('Enter a chore name and how often it repeats, in days.');S.tasks.push({id:uid(),name:n,every:e,who:document.getElementById('in-who').value,last:now()})}
  else if(a==='addmember'){const n=val('in-mem');if(!n)return;S.members.push({id:uid(),name:n})}
  save();render();
}
document.addEventListener('click',e=>{const b=e.target.closest('button[data-a]');if(b&&!b.disabled)act(b.dataset.a,b.dataset.id)});
document.addEventListener('change',e=>{const c=e.target;if(c.type==='checkbox'&&c.dataset.a)act(c.dataset.a,c.dataset.id)});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.dataset&&e.target.dataset.enter)act(e.target.dataset.enter)});
render();
