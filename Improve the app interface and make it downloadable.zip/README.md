# Homebase

A calmer way to run your household: predict when essentials run out, keep a shared shopping list, split chores fairly, and ask questions about your home.

## Run it

Open `index.html` in a browser, or serve the folder over HTTP:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Install it

Homebase is now packaged as a Progressive Web App. When hosted over HTTPS, supported browsers can install it to a phone or desktop and keep the app shell available offline. Household data is stored locally in the browser using `localStorage`.

## Files

- `index.html`: page shell, metadata, favicon, and PWA registration
- `style.css`: responsive visual system, light/dark themes, cards, navigation, and responsive layout
- `app.js`: state, run-out predictor, views, and actions
- `manifest.webmanifest`: install metadata and app identity
- `sw.js`: offline shell cache

## Product notes

The redesigned interface uses a more recognizable Homebase brand, stronger dashboard hierarchy, clearer status colors, and touch-friendly controls. The data model remains local-first and dependency-free, so the app can be downloaded and hosted as a static site without a build step.

The “Ask Homebase” box still uses `claude.use('sample')` when available inside Claude. Outside that environment it shows a friendly fallback; connect it to a backend before using it as a public AI feature. Never put an API key in front-end code.

Family-wide sync, accounts, push reminders, translations, receipt scanning, and grocery integrations can be added later with a backend or native mobile wrapper.
