# Homebase Play Store research

Verified November 11, 2026 from official Google sources.

- New personal Play Console accounts created after November 13, 2023 must run a closed test with at least 12 testers opted in continuously for 14 days before requesting production access: https://support.google.com/googleplay/android-developer/answer/14151465?hl=en
- All developers publishing on Google Play must complete the Data Safety form. Even apps collecting no user data need a privacy-policy URL: https://support.google.com/googleplay/android-developer/answer/10787469?hl=en
- A privacy policy must be a public HTTPS webpage, accessible worldwide, and available both in the store listing and inside the app: https://support.google.com/googleplay/android-developer/answer/9859455?hl=en
- Starting August 31, 2026, new apps and updates must target Android 16 / API 36: https://developer.android.com/google/play/requirements/target-sdk
- Trusted Web Activity with Bubblewrap can package an existing PWA into an Android APK and App Bundle, with Digital Asset Links used to prove website ownership: https://developer.android.com/develop/ui/views/layout/webapps/guide-trusted-web-activities-version2
- Google Play Billing supports one-time digital purchases and subscriptions. Billing Library 8 or newer is required for new apps and updates after August 31, 2026: https://developer.android.com/google/play/billing
- Play Console account setup includes the developer agreement, registration fee, account type, and identity verification: https://support.google.com/googleplay/android-developer/answer/6112435?hl=en
